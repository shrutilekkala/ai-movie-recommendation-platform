from __future__ import annotations

import argparse
import asyncio
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from typing import Any

from sqlalchemy import delete, select

from app.core.config import settings
from app.db.session import SessionLocal
from app.models.content import Content

from app.services.genre_validation import (
    serialize_genres,
    validate_movie_genres,
)


API_BASE = "https://api.themoviedb.org/3"

ACCENTS = [
    "neon",
    "violet",
    "cosmic",
    "sunset",
    "ember",
    "electric",
    "aqua",
    "rose",
    "lime",
    "ocean",
    "gold",
    "ice",
]


# ============================================================
# TMDB HTTP
# ============================================================

def _get(
    path: str,
    params: dict[str, Any] | None = None,
    retries: int = 3,
) -> dict[str, Any]:

    token = (
        settings
        .tmdb_bearer_token
        .strip()
    )

    if not token:

        raise RuntimeError(
            "TMDB_BEARER_TOKEN is missing."
        )

    query = urllib.parse.urlencode(
        params or {}
    )

    url = (
        f"{API_BASE}{path}"
        +
        (
            f"?{query}"
            if query
            else ""
        )
    )

    request = urllib.request.Request(
        url,
        headers={
            "Authorization":
                f"Bearer {token}",

            "accept":
                "application/json",

            "User-Agent":
                "NEXUS-Portfolio/6.4",
        },
    )

    last_error: Exception | None = None

    for attempt in range(
        1,
        retries + 1,
    ):

        try:

            with urllib.request.urlopen(
                request,
                timeout=45,
            ) as response:

                return json.loads(
                    response
                    .read()
                    .decode(
                        "utf-8"
                    )
                )

        except (
            urllib.error.HTTPError,
            urllib.error.URLError,
            TimeoutError,
        ) as exc:

            last_error = exc

            if attempt >= retries:
                break

            delay = (
                attempt
                * 1.5
            )

            print(
                (
                    f"TMDB request failed "
                    f"for {path}. "
                    f"Retrying in "
                    f"{delay:.1f}s..."
                )
            )

            time.sleep(
                delay
            )

    raise RuntimeError(
        (
            f"TMDB request failed "
            f"for {path}: "
            f"{last_error}"
        )
    )


# ============================================================
# HELPERS
# ============================================================

def _year(
    value: str | None,
) -> int:

    if not value:
        return 0

    try:

        return datetime.strptime(
            value,
            "%Y-%m-%d",
        ).year

    except ValueError:

        return 0


def _safe_int(
    value: Any,
    default: int = 0,
) -> int:

    try:

        return int(
            value
            if value is not None
            else default
        )

    except (
        TypeError,
        ValueError,
    ):

        return default


def _safe_float(
    value: Any,
    default: float = 0.0,
) -> float:

    try:

        return float(
            value
            if value is not None
            else default
        )

    except (
        TypeError,
        ValueError,
    ):

        return default


def _extract_tmdb_genres(
    details: dict[str, Any],
) -> list[str]:

    genres: list[str] = []

    for row in details.get(
        "genres",
        [],
    ):

        name = str(
            row.get(
                "name"
            )
            or ""
        ).strip()

        if name:

            genres.append(
                name
            )

    return genres


# ============================================================
# DISCOVERY
# ============================================================

def _discover_telugu(
    pages: int,
) -> tuple[
    list[dict[str, Any]],
    dict[int, str],
]:

    genre_payload = _get(
        "/genre/movie/list",
        {
            "language":
                "en-US",
        },
    )

    genre_map = {
        int(row["id"]):
            row["name"]

        for row
        in genre_payload.get(
            "genres",
            [],
        )
    }

    rows: list[
        dict[str, Any]
    ] = []

    seen: set[int] = set()

    for page in range(
        1,
        max(
            1,
            pages,
        )
        + 1,
    ):

        payload = _get(
            "/discover/movie",
            {
                "include_adult":
                    "false",

                "include_video":
                    "false",

                "language":
                    "en-US",

                "page":
                    page,

                "sort_by":
                    "popularity.desc",

                "with_original_language":
                    "te",
            },
        )

        results = payload.get(
            "results",
            [],
        )

        if not results:
            break

        for movie in results:

            movie_id = _safe_int(
                movie.get(
                    "id"
                )
            )

            if not movie_id:
                continue

            if movie_id in seen:
                continue

            seen.add(
                movie_id
            )

            rows.append(
                movie
            )

        total_pages = _safe_int(
            payload.get(
                "total_pages"
            ),
            page,
        )

        print(
            (
                f"Fetched TMDB Telugu page "
                f"{page}/"
                f"{min(total_pages, pages)} "
                f"({len(rows)} unique movies)"
            )
        )

        if page >= total_pages:
            break

    return (
        rows,
        genre_map,
    )


# ============================================================
# MOVIE DETAILS
# ============================================================

def _fetch_movie_details(
    tmdb_id: int,
) -> dict[str, Any]:

    return _get(
        f"/movie/{tmdb_id}",
        {
            "language":
                "en-US",
        },
    )


def _fetch_details_safe(
    movie: dict[str, Any],
) -> dict[str, Any]:

    tmdb_id = _safe_int(
        movie.get(
            "id"
        )
    )

    if not tmdb_id:

        return {
            **movie,
            "_details": {},
            "_details_error":
                "missing tmdb id",
        }

    try:

        details = _fetch_movie_details(
            tmdb_id
        )

        return {
            **movie,
            "_details":
                details,
        }

    except Exception as exc:

        return {
            **movie,

            "_details":
                {},

            "_details_error":
                str(exc)[:180],
        }


def _fetch_all_details(
    movies: list[
        dict[str, Any]
    ],
) -> list[
    dict[str, Any]
]:

    enriched: list[
        dict[str, Any]
    ] = []

    total = len(
        movies
    )

    print(
        (
            f"Fetching details/runtime/genres "
            f"for {total} Telugu movies..."
        )
    )

    for index, movie in enumerate(
        movies,
        start=1,
    ):

        enriched.append(
            _fetch_details_safe(
                movie
            )
        )

        if (
            index % 20 == 0
            or index == total
        ):

            print(
                (
                    f"Fetching details "
                    f"{index}/{total}"
                )
            )

        time.sleep(
            0.05
        )

    return enriched


# ============================================================
# IMPORT
# ============================================================

async def import_telugu(
    force: bool = False,
    pages: int | None = None,
) -> None:

    requested_pages = (
        pages
        or settings.tmdb_telugu_pages
    )

    movies, genre_map = (
        await asyncio.to_thread(
            _discover_telugu,
            requested_pages,
        )
    )

    if not movies:

        print(
            "TMDB returned no Telugu movies."
        )

        return

    movies = await asyncio.to_thread(
        _fetch_all_details,
        movies,
    )

    async with SessionLocal() as db:

        if force:

            print(
                (
                    "Deleting existing "
                    "TMDB-only Telugu rows..."
                )
            )

            await db.execute(
                delete(
                    Content
                ).where(
                    Content.catalog_source
                    == "tmdb",

                    Content.original_language
                    == "te",
                )
            )

            await db.commit()

        existing_rows = list(
            (
                await db.scalars(
                    select(
                        Content
                    ).where(
                        Content.tmdb_id
                        .is_not(
                            None
                        )
                    )
                )
            ).all()
        )

        by_tmdb = {
            int(
                row.tmdb_id
            ):
                row

            for row
            in existing_rows

            if row.tmdb_id
            is not None
        }

        inserted = 0
        enriched_existing = 0
        skipped = 0

        details_processed = 0
        details_failed = 0

        runtime_available = 0
        runtime_missing = 0

        genre_tmdb = 0
        genre_fallback = 0
        genre_overrides = 0
        genre_changed = 0
        genre_unknown = 0

        for movie in movies:

            tmdb_id = _safe_int(
                movie.get(
                    "id"
                )
            )

            if not tmdb_id:

                skipped += 1
                continue

            details = (
                movie.get(
                    "_details"
                )
                or {}
            )

            if details:

                details_processed += 1

            else:

                details_failed += 1

            # ------------------------------------------------
            # LANGUAGE
            # ------------------------------------------------

            original_language = str(
                details.get(
                    "original_language"
                )
                or movie.get(
                    "original_language"
                )
                or "te"
            ).strip().lower()

            if original_language != "te":

                skipped += 1
                continue

            # ------------------------------------------------
            # GENRES
            # ------------------------------------------------

            raw_genres = (
                _extract_tmdb_genres(
                    details
                )
            )

            # Fallback only when /movie details
            # contains no genre list.
            if not raw_genres:

                raw_genres = [
                    genre_map.get(
                        _safe_int(
                            genre_id
                        ),
                        "",
                    )

                    for genre_id
                    in movie.get(
                        "genre_ids",
                        [],
                    )
                ]

                raw_genres = [
                    genre
                    for genre
                    in raw_genres
                    if genre
                ]

                if raw_genres:
                    genre_fallback += 1

            else:

                genre_tmdb += 1

            validation = (
                validate_movie_genres(
                    tmdb_id=
                        tmdb_id,

                    tmdb_genres=
                        raw_genres,
                )
            )

            if (
                validation[
                    "source"
                ]
                == "manual_override"
            ):

                genre_overrides += 1

            if validation[
                "changed"
            ]:

                genre_changed += 1

            primary, genres = (
                serialize_genres(
                    validation[
                        "genres"
                    ]
                )
            )

            if genres == "Other":

                genre_unknown += 1

            # ------------------------------------------------
            # RUNTIME
            # ------------------------------------------------

            runtime_raw = (
                details.get(
                    "runtime"
                )
            )

            runtime: int | None = None

            if runtime_raw is not None:

                parsed_runtime = (
                    _safe_int(
                        runtime_raw
                    )
                )

                if parsed_runtime > 0:

                    runtime = (
                        parsed_runtime
                    )

            if runtime is not None:

                runtime_available += 1

            else:

                runtime_missing += 1

            stored_runtime = (
                runtime
                if runtime is not None
                else 0
            )

            # ------------------------------------------------
            # GENERAL METADATA
            # ------------------------------------------------

            title = str(
                details.get(
                    "title"
                )
                or movie.get(
                    "title"
                )
                or movie.get(
                    "original_title"
                )
                or f"TMDB {tmdb_id}"
            ).strip()

            original_title = str(
                details.get(
                    "original_title"
                )
                or movie.get(
                    "original_title"
                )
                or title
            ).strip()

            overview = str(
                details.get(
                    "overview"
                )
                or movie.get(
                    "overview"
                )
                or ""
            ).strip()

            release_date = (
                details.get(
                    "release_date"
                )
                or movie.get(
                    "release_date"
                )
            )

            vote_average = (
                _safe_float(
                    details.get(
                        "vote_average"
                    )
                    if details
                    else movie.get(
                        "vote_average"
                    )
                )
            )

            vote_count = (
                _safe_int(
                    details.get(
                        "vote_count"
                    )
                    if details
                    else movie.get(
                        "vote_count"
                    )
                )
            )

            popularity = (
                _safe_float(
                    details.get(
                        "popularity"
                    )
                    if details
                    else movie.get(
                        "popularity"
                    )
                )
            )

            quality = min(
                0.99,
                max(
                    0.50,
                    (
                        vote_average
                        / 10.0
                        if vote_average
                        else 0.55
                    ),
                ),
            )

            poster_path = (
                details.get(
                    "poster_path"
                )
                or movie.get(
                    "poster_path"
                )
            )

            backdrop_path = (
                details.get(
                    "backdrop_path"
                )
                or movie.get(
                    "backdrop_path"
                )
            )

            # ------------------------------------------------
            # UPDATE EXISTING
            # ------------------------------------------------

            existing = (
                by_tmdb.get(
                    tmdb_id
                )
            )

            if existing:

                existing.title = (
                    title[:220]
                )

                existing.original_language = (
                    original_language
                )

                existing.original_title = (
                    original_title[:250]
                )

                existing.poster_path = (
                    poster_path
                )

                existing.backdrop_path = (
                    backdrop_path
                )

                existing.tmdb_popularity = (
                    popularity
                )

                existing.tmdb_vote_average = (
                    vote_average
                )

                existing.tmdb_vote_count = (
                    vote_count
                )

                existing.match_score = (
                    quality
                )

                existing.year = (
                    _year(
                        release_date
                    )
                )

                if runtime is not None:

                    existing.duration_minutes = (
                        runtime
                    )

                if overview:

                    existing.synopsis = (
                        overview
                    )

                # Genre validation is now authoritative.
                existing.genre = (
                    primary[:120]
                )

                existing.genres = (
                    genres
                )

                enriched_existing += 1

                continue

            # ------------------------------------------------
            # INSERT NEW
            # ------------------------------------------------

            synopsis = (
                overview
                or
                (
                    "Telugu movie from TMDB. "
                    f"Genres: "
                    f"{genres.replace('|', ', ')}."
                )
            )

            row = Content(
                title=
                    title[:220],

                synopsis=
                    synopsis,

                genre=
                    primary[:120],

                genres=
                    genres,

                tags=
                    (
                        "Telugu, Telugu cinema, "
                        "Tollywood"
                    ),

                content_type=
                    "Movie",

                year=
                    _year(
                        release_date
                    ),

                duration_minutes=
                    stored_runtime,

                match_score=
                    quality,

                maturity_rating=
                    "NR",

                accent=
                    ACCENTS[
                        tmdb_id
                        %
                        len(
                            ACCENTS
                        )
                    ],

                featured=
                    False,

                catalog_source=
                    "tmdb",

                tmdb_id=
                    tmdb_id,

                original_language=
                    original_language,

                original_title=
                    original_title[:250],

                poster_path=
                    poster_path,

                backdrop_path=
                    backdrop_path,

                tmdb_popularity=
                    popularity,

                tmdb_vote_average=
                    vote_average,

                tmdb_vote_count=
                    vote_count,
            )

            db.add(
                row
            )

            by_tmdb[
                tmdb_id
            ] = row

            inserted += 1

        await db.commit()

    # ========================================================
    # SUMMARY
    # ========================================================

    print()

    print(
        json.dumps(
            {
                "source":
                    "TMDB",

                "language":
                    "te",

                "fetched":
                    len(
                        movies
                    ),

                "inserted":
                    inserted,

                "enriched_existing":
                    enriched_existing,

                "skipped":
                    skipped,

                "pages_requested":
                    requested_pages,

                "details_processed":
                    details_processed,

                "details_failed":
                    details_failed,

                "runtime_available":
                    runtime_available,

                "runtime_missing":
                    runtime_missing,

                "genre_tmdb":
                    genre_tmdb,

                "genre_discover_fallback":
                    genre_fallback,

                "genre_manual_overrides":
                    genre_overrides,

                "genre_changed":
                    genre_changed,

                "genre_unknown":
                    genre_unknown,
            },
            indent=2,
        )
    )

    print()

    print(
        "Telugu genre-validation import complete."
    )

    print(
        "Rebuild Qdrant:"
    )

    print(
        (
            "docker compose exec backend "
            "python -m app.scripts.build_semantic_index"
        )
    )


# ============================================================
# CLI
# ============================================================

def main() -> None:

    if not (
        settings
        .tmdb_bearer_token
        .strip()
    ):

        print(
            "TMDB_BEARER_TOKEN is missing."
        )

        raise SystemExit(
            2
        )

    parser = argparse.ArgumentParser(
        description=(
            "Import, enrich, and validate "
            "Telugu movie metadata from TMDB."
        )
    )

    parser.add_argument(
        "--force",
        action=
            "store_true",

        help=
            (
                "Delete TMDB-only Telugu rows "
                "before rebuilding the catalog."
            ),
    )

    parser.add_argument(
        "--pages",
        type=
            int,

        default=
            None,

        help=
            (
                "Number of TMDB Discover "
                "pages to process."
            ),
    )

    args = (
        parser.parse_args()
    )

    asyncio.run(
        import_telugu(
            force=
                args.force,

            pages=
                args.pages,
        )
    )


if __name__ == "__main__":
    main()