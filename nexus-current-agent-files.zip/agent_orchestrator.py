from __future__ import annotations

import json
from typing import Any

from redis.asyncio import Redis
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.agent import parse_intent
from app.core.config import settings

from app.models.user import (
    User,
    UserContentState,
)

from app.services.recommender import (
    nexus_recommendations,
)

from app.services.semantic import (
    discovery_search,
)


# ============================================================
# USER PROFILE
# ============================================================

async def get_user_profile(
    db: AsyncSession,
    user_id: int | None,
) -> dict[str, Any]:

    if user_id is None:

        return {
            "authenticated": False,
            "favorite_genres": [],
            "liked_content_ids": [],
            "disliked_content_ids": [],
            "my_list_content_ids": [],
        }

    user = await db.get(
        User,
        user_id,
    )

    if user is None:

        return {
            "authenticated": False,
            "favorite_genres": [],
            "liked_content_ids": [],
            "disliked_content_ids": [],
            "my_list_content_ids": [],
        }

    states = list(
        (
            await db.scalars(
                select(
                    UserContentState
                ).where(
                    UserContentState.user_id
                    == user_id
                )
            )
        ).all()
    )

    favorite_genres = [
        genre.strip()
        for genre in (
            user.favorite_genres
            or ""
        ).split(",")
        if genre.strip()
    ]

    return {
        "authenticated":
            True,

        "user_id":
            user.id,

        "display_name":
            user.display_name,

        "favorite_genres":
            favorite_genres,

        "liked_content_ids":
            [
                state.content_id
                for state in states
                if state.reaction
                == "like"
            ],

        "disliked_content_ids":
            [
                state.content_id
                for state in states
                if state.reaction
                == "dislike"
            ],

        "my_list_content_ids":
            [
                state.content_id
                for state in states
                if bool(
                    state.in_my_list
                )
            ],
    }


# ============================================================
# REDIS SESSION
# ============================================================

async def get_session_context(
    user_id: int | None,
) -> dict[str, Any]:

    if user_id is None:

        return {
            "available": False,
            "event_count": 0,
            "genre_affinity": [],
            "recent_events": [],
        }

    redis = Redis.from_url(
        settings.redis_url,
        decode_responses=True,
    )

    key = (
        f"nexus:session:{user_id}"
    )

    try:

        genres = await redis.hgetall(
            f"{key}:genres"
        )

        metadata = await redis.hgetall(
            key
        )

        raw_events = await redis.lrange(
            f"{key}:events",
            0,
            9,
        )

        genre_affinity = sorted(
            [
                {
                    "genre":
                        genre,

                    "score":
                        round(
                            float(score),
                            3,
                        ),
                }

                for genre, score
                in genres.items()
            ],
            key=lambda row:
                row["score"],
            reverse=True,
        )

        recent_events = []

        for event in raw_events:

            try:
                recent_events.append(
                    json.loads(
                        event
                    )
                )

            except json.JSONDecodeError:
                continue

        return {
            "available":
                bool(
                    genres
                    or metadata
                    or raw_events
                ),

            "event_count":
                int(
                    metadata.get(
                        "event_count",
                        0,
                    )
                ),

            "last_event_type":
                metadata.get(
                    "last_event_type"
                ),

            "updated_at":
                metadata.get(
                    "updated_at"
                ),

            "genre_affinity":
                genre_affinity,

            "recent_events":
                recent_events,
        }

    except Exception as exc:

        return {
            "available":
                False,

            "event_count":
                0,

            "genre_affinity":
                [],

            "recent_events":
                [],

            "error":
                str(exc)[:160],
        }

    finally:

        try:
            await redis.aclose()

        except Exception:
            pass


# ============================================================
# GENRE HELPERS
# ============================================================

def normalize_genre(
    value: str,
) -> str:

    return (
        value
        .strip()
        .lower()
        .replace("_", "-")
    )


def content_genres(
    content: dict[str, Any],
) -> set[str]:

    return {
        normalize_genre(
            genre
        )

        for genre in (
            content.get(
                "genres"
            )
            or content.get(
                "genre"
            )
            or ""
        ).split("|")

        if genre.strip()
    }


# ============================================================
# HARD CONSTRAINT VALIDATOR
# ============================================================

def satisfies_hard_constraints(
    content: dict[str, Any],
    intent: dict[str, Any],
) -> tuple[
    bool,
    list[str],
]:

    reasons: list[str] = []

    # --------------------------------------------------------
    # LANGUAGE
    # --------------------------------------------------------

    language = (
        intent.get(
            "language"
        )
    )

    if language:

        actual_language = (
            content.get(
                "original_language"
            )
            or "en"
        ).lower()

        if (
            actual_language
            != language.lower()
        ):

            reasons.append(
                (
                    "language mismatch: "
                    f"wanted {language}, "
                    f"got {actual_language}"
                )
            )

    actual_genres = (
        content_genres(
            content
        )
    )

    # --------------------------------------------------------
    # REQUIRED GENRES
    # --------------------------------------------------------

    required_genres = {
        normalize_genre(
            str(
                genre
            )
        )

        for genre in intent.get(
            "genres",
            [],
        )

        if str(
            genre
        ).strip()
    }

    genre_match_mode = intent.get(
        "genre_match_mode",
        "all",
    )

    genre_constraint_failed = (
        bool(required_genres)
        and (
            (
                genre_match_mode == "all"
                and not required_genres.issubset(actual_genres)
            )
            or
            (
                genre_match_mode == "any"
                and not bool(required_genres & actual_genres)
            )
        )
    )

    if genre_constraint_failed:

        missing = (
            required_genres
            -
            actual_genres
        )

        reasons.append(
            (
                "required genre mismatch: "
                "missing "
                +
                ", ".join(
                    sorted(
                        missing
                    )
                )
            )
        )

    # --------------------------------------------------------
    # EXCLUDED GENRES
    # --------------------------------------------------------

    excluded_genres = {
        normalize_genre(
            str(
                genre
            )
        )

        for genre in intent.get(
            "excluded_genres",
            [],
        )

        if str(
            genre
        ).strip()
    }

    blocked = (
        excluded_genres
        &
        actual_genres
    )

    if blocked:

        reasons.append(
            (
                "excluded genre: "
                +
                ", ".join(
                    sorted(
                        blocked
                    )
                )
            )
        )

    # ========================================================
    # STRICT RUNTIME
    #
    # User says:
    # "under 2 hours"
    #
    # Then:
    # runtime must be KNOWN
    # AND runtime <= 120.
    #
    # Runtime 0 is UNKNOWN and must be rejected.
    # ========================================================

    max_minutes = (
        intent.get(
            "max_minutes"
        )
    )

    if max_minutes is not None:

        duration = (
            content.get(
                "duration_minutes"
            )
        )

        if (
            duration is None
            or int(duration) <= 0
        ):

            reasons.append(
                (
                    "runtime unknown for "
                    "requested runtime constraint"
                )
            )

        elif (
            int(duration)
            > int(
                max_minutes
            )
        ):

            reasons.append(
                (
                    f"runtime "
                    f"{duration} > "
                    f"{max_minutes}"
                )
            )

    return (
        len(reasons) == 0,
        reasons,
    )


# ============================================================
# REQUESTED GENRE SCORE
# ============================================================

def requested_genre_score(
    content: dict[str, Any],
    intent: dict[str, Any],
) -> float:

    requested = {
        normalize_genre(
            str(
                genre
            )
        )

        for genre in intent.get(
            "genres",
            [],
        )

        if str(
            genre
        ).strip()
    }

    if not requested:

        return 0.0

    actual = (
        content_genres(
            content
        )
    )

    overlap = len(
        requested
        & actual
    )

    return overlap / len(requested)


# ============================================================
# SESSION SCORE
# ============================================================

def session_genre_score(
    content: dict[str, Any],
    session: dict[str, Any],
) -> float:

    affinities = {
        normalize_genre(
            str(
                row[
                    "genre"
                ]
            )
        ):
            float(
                row[
                    "score"
                ]
            )

        for row in session.get(
            "genre_affinity",
            [],
        )
    }

    genres = (
        content_genres(
            content
        )
    )

    if not genres:

        return 0.0

    raw = max(
        (
            affinities.get(
                genre,
                0.0,
            )

            for genre in genres
        ),
        default=0.0,
    )

    return max(
        -1.0,
        min(
            1.0,
            raw / 3.0,
        ),
    )


# ============================================================
# CONTENT SERIALIZER
# ============================================================

def content_to_dict(
    raw_content: Any,
) -> dict[str, Any]:

    if raw_content is None:
        return {}

    if isinstance(
        raw_content,
        dict,
    ):
        return dict(
            raw_content
        )

    if hasattr(
        raw_content,
        "__table__",
    ):

        return {
            column.name:
                getattr(
                    raw_content,
                    column.name,
                )

            for column
            in raw_content
            .__table__
            .columns
        }

    return {}


# ============================================================
# MERGE CANDIDATES
# ============================================================

def merge_candidates(
    semantic_results:
        list[dict[str, Any]],

    recommendation_results:
        list[dict[str, Any]],

    intent:
        dict[str, Any],

    session:
        dict[str, Any],

    limit:
        int,

) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
]:

    candidates: dict[
        int,
        dict[str, Any],
    ] = {}

    rejected: list[
        dict[str, Any]
    ] = []

    # --------------------------------------------------------
    # SEMANTIC CANDIDATES
    # --------------------------------------------------------

    for result in semantic_results:

        content = (
            result.get(
                "content"
            )
            or {}
        )

        content_id = (
            content.get(
                "id"
            )
        )

        if content_id is None:
            continue

        row = candidates.setdefault(
            int(
                content_id
            ),
            {
                "content":
                    content,

                "semantic_score":
                    0.0,

                "recommendation_score":
                    0.0,

                "semantic_reason":
                    None,

                "recommendation_reason":
                    None,
            },
        )

        row[
            "semantic_score"
        ] = float(
            result.get(
                "score",
                0.0,
            )
        )

        row[
            "semantic_reason"
        ] = (
            result.get(
                "reason"
            )
        )

    # --------------------------------------------------------
    # RECOMMENDATION CANDIDATES
    # --------------------------------------------------------

    for result in recommendation_results:

        content = (
            content_to_dict(
                result.get(
                    "content"
                )
            )
        )

        content_id = (
            content.get(
                "id"
            )
        )

        if content_id is None:
            continue

        row = candidates.setdefault(
            int(
                content_id
            ),
            {
                "content":
                    content,

                "semantic_score":
                    0.0,

                "recommendation_score":
                    0.0,

                "semantic_reason":
                    None,

                "recommendation_reason":
                    None,
            },
        )

        row[
            "recommendation_score"
        ] = float(
            result.get(
                "score",
                0.0,
            )
        )

        row[
            "recommendation_reason"
        ] = (
            result.get(
                "reason"
            )
        )

    ranked = []

    # --------------------------------------------------------
    # FINAL SAFETY GATE
    # --------------------------------------------------------

    for (
        content_id,
        candidate,
    ) in candidates.items():

        content = (
            candidate[
                "content"
            ]
        )

        (
            allowed,
            rejection_reasons,
        ) = satisfies_hard_constraints(
            content,
            intent,
        )

        if not allowed:

            rejected.append(
                {
                    "content_id":
                        content_id,

                    "title":
                        content.get(
                            "title"
                        ),

                    "genres":
                        content.get(
                            "genres"
                        ),

                    "runtime":
                        content.get(
                            "duration_minutes"
                        ),

                    "reasons":
                        rejection_reasons,
                }
            )

            continue

        semantic = (
            candidate[
                "semantic_score"
            ]
        )

        recommendation = (
            candidate[
                "recommendation_score"
            ]
        )

        genre = (
            requested_genre_score(
                content,
                intent,
            )
        )

        live_session = (
            session_genre_score(
                content,
                session,
            )
        )

        final_score = (
            0.55 * semantic
            +
            0.25 * recommendation
            +
            0.12 * genre
            +
            0.08 * max(
                0.0,
                live_session,
            )
        )

        if live_session < 0:

            final_score += (
                0.06
                * live_session
            )

        final_score = max(
            0.0,
            min(
                0.99,
                final_score,
            ),
        )

        reasons = []

        if candidate[
            "semantic_reason"
        ]:

            reasons.append(
                candidate[
                    "semantic_reason"
                ]
            )

        if candidate[
            "recommendation_reason"
        ]:

            reasons.append(
                candidate[
                    "recommendation_reason"
                ]
            )

        if genre > 0:

            reasons.append(
                (
                    "Matches all requested genres"
                    if intent.get("genre_match_mode", "all") == "all" and genre >= 1.0
                    else "Matches requested genre preferences"
                )
            )

        if live_session > 0.15:

            reasons.append(
                (
                    "Fits your live "
                    "session taste"
                )
            )

        ranked.append(
            {
                "content":
                    content,

                "score":
                    round(
                        final_score,
                        4,
                    ),

                "reason":
                    (
                        "; ".join(
                            dict.fromkeys(
                                reasons
                            )
                        )

                        or

                        "Best valid agent match"
                    ),

                "agent_signals":
                    {
                        "semantic":
                            round(
                                semantic,
                                4,
                            ),

                        "personalized_recommendation":
                            round(
                                recommendation,
                                4,
                            ),

                        "requested_genre":
                            round(
                                genre,
                                4,
                            ),

                        "live_session":
                            round(
                                live_session,
                                4,
                            ),

                        "final_score":
                            round(
                                final_score,
                                4,
                            ),
                    },
            }
        )

    ranked.sort(
        key=lambda row:
            row[
                "score"
            ],
        reverse=True,
    )

    return (
        ranked[
            :limit
        ],
        rejected,
    )


# ============================================================
# MAIN AGENT
# ============================================================

async def run_agent(
    db: AsyncSession,
    query: str,
    user_id: int | None = None,
    limit: int = 10,
) -> dict[str, Any]:

    trace: list[
        dict[str, Any]
    ] = []

    # --------------------------------------------------------
    # STEP 1 — INTENT
    # --------------------------------------------------------

    intent = parse_intent(
        query
    )

    trace.append(
        {
            "step":
                1,

            "tool":
                "intent_parser",

            "status":
                "success",

            "detail":
                (
                    "Detected "
                    f"{len(intent['hard_constraints'])} "
                    "hard constraints and "
                    f"{len(intent['soft_preferences'])} "
                    "soft preferences."
                ),
        }
    )

    # --------------------------------------------------------
    # STEP 2 — PROFILE
    # --------------------------------------------------------

    profile = (
        await get_user_profile(
            db,
            user_id,
        )
    )

    trace.append(
        {
            "step":
                2,

            "tool":
                "user_profile",

            "status":
                "success",

            "detail":
                (
                    "Loaded PostgreSQL user profile."
                    if profile[
                        "authenticated"
                    ]

                    else

                    "Anonymous request; profile skipped."
                ),
        }
    )

    # --------------------------------------------------------
    # STEP 3 — SESSION
    # --------------------------------------------------------

    session = (
        await get_session_context(
            user_id
        )
    )

    trace.append(
        {
            "step":
                3,

            "tool":
                "session_context",

            "status":
                "success",

            "detail":
                (
                    f"Loaded "
                    f"{session['event_count']} "
                    "live interaction events from Redis."
                    if session[
                        "available"
                    ]

                    else

                    "No live session context available."
                ),
        }
    )

    # --------------------------------------------------------
    # STEP 4 — SEMANTIC SEARCH
    # --------------------------------------------------------

    semantic = (
        await discovery_search(
            db=
                db,

            query=
                query,

            user_id=
                user_id,

            limit=
                max(
                    limit * 4,
                    40,
                ),

            source=
                "agent",

            language=
                (
                    intent.get(
                        "language"
                    )
                    or "all"
                ),
        )
    )

    semantic_results = (
        semantic.get(
            "results",
            [],
        )
    )

    trace.append(
        {
            "step":
                4,

            "tool":
                "semantic_search",

            "status":
                (
                    "success"
                    if semantic.get(
                        "semantic_ready"
                    )
                    else
                    "degraded"
                ),

            "detail":
                (
                    f"Retrieved "
                    f"{len(semantic_results)} "
                    "constraint-valid semantic candidates."
                ),
        }
    )

    # --------------------------------------------------------
    # STEP 5 — RECOMMENDER
    # --------------------------------------------------------

    recommendation_results: list[
        dict[str, Any]
    ] = []

    if user_id is not None:

        try:

            recommendation_results = (
                await nexus_recommendations(
                    db,
                    user_id,
                    limit=max(
                        limit * 4,
                        40,
                    ),
                )
            )

            trace.append(
                {
                    "step":
                        5,

                    "tool":
                        "hybrid_recommender",

                    "status":
                        "success",

                    "detail":
                        (
                            f"Retrieved "
                            f"{len(recommendation_results)} "
                            "personalized candidates."
                        ),
                }
            )

        except Exception as exc:

            trace.append(
                {
                    "step":
                        5,

                    "tool":
                        "hybrid_recommender",

                    "status":
                        "degraded",

                    "detail":
                        str(exc)[:160],
                }
            )

    else:

        trace.append(
            {
                "step":
                    5,

                "tool":
                    "hybrid_recommender",

                "status":
                    "skipped",

                "detail":
                    (
                        "Authentication required "
                        "for personalized recommendations."
                    ),
            }
        )

    # --------------------------------------------------------
    # STEP 6 — CONSTRAINT RERANK
    # --------------------------------------------------------

    (
        results,
        rejected,
    ) = merge_candidates(
        semantic_results,
        recommendation_results,
        intent,
        session,
        limit,
    )

    trace.append(
        {
            "step":
                6,

            "tool":
                "constraint_reranker",

            "status":
                "success",

            "detail":
                (
                    f"Returned "
                    f"{len(results)} "
                    "final candidates; "
                    f"rejected "
                    f"{len(rejected)} "
                    "candidates that violated "
                    "hard constraints."
                ),
        }
    )

    tools_used = [
        row[
            "tool"
        ]

        for row in trace

        if row[
            "status"
        ] in {
            "success",
            "degraded",
        }
    ]

    return {
        "query":
            query,

        "intent":
            intent,

        "tools_used":
            tools_used,

        "trace":
            trace,

        "context":
            {
                "profile":
                    profile,

                "session":
                    session,
            },

        "candidate_summary":
            {
                "semantic_candidates":
                    len(
                        semantic_results
                    ),

                "recommendation_candidates":
                    len(
                        recommendation_results
                    ),

                "rejected_candidates":
                    len(
                        rejected
                    ),

                "returned_candidates":
                    len(
                        results
                    ),
            },

        "results":
            results,

        "rejected_count":
            len(
                rejected
            ),

        "rejected":
            rejected[
                :30
            ],

        "agent_version":
            "6.4.0-flexible-multigenre",
    }